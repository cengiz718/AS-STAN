package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.*

@Database(
    entities = [
        LessonPlanEntity::class,
        ReadingRecordEntity::class,
        QuestionEntity::class,
        CompositionEntity::class,
        SavedWordEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun lessonPlanDao(): LessonPlanDao
    abstract fun readingRecordDao(): ReadingRecordDao
    abstract fun questionDao(): QuestionDao
    abstract fun compositionDao(): CompositionDao
    abstract fun savedWordDao(): SavedWordDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "turkce_asistani_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
